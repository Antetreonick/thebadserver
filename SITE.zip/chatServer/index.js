const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8082 });
wss.broadcast = function(data) { wss.clients.forEach(client => client.send(data)); };

wss.on("connection", (ws, req) => {

    if (req.headers.origin == "http://192.168.1.3:8084") {
        ws.on("message", data => {
            const ee = JSON.parse(data);
            if (ee.t == 'con') {
                ws.send(`${data}`);
            } else if (ee.t == 'm') {
                wss.broadcast(`${data}`);
            }
        });
    } else {
        ws.close();
    }
});